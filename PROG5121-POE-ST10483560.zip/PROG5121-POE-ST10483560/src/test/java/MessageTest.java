


import com.mycompany.prog5121.poe.st10483560.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author pc
 */
public class MessageTest {
    
    public MessageTest() {
    }

    @Test
    public void testCheckMessageID() {
    }

    @Test
    public void testCheckRecipientCell() {
    }

    @Test
    public void testSendMessage() {
    }

    @Test
    public void testPrintMessages() {
    }

    @Test
    public void testRegisterMessage() {
    }

    @Test
    public void testReturnTotalMessages() {
    }
    @Test
    public void testProcessUserSelection() {
        //assertEquals("Message successfully sent.", Message. (1));
        //assertEquals("Press 0 to delete message.", service.processUserSelection(2));
        //assertEquals("Message successfully stored.", service.processUserSelection(3));
    }
}

