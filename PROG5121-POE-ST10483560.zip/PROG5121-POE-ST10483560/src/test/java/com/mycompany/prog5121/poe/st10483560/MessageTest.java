package com.mycompany.prog5121.poe.st10483560;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageLength_Success() {
        String content = "This is a test message under 250 characters.";
        Message message = new Message("MSG001", "0123456789", content);
        String result = message.checkMessageLength();
        assertEquals("Message ready to send.", result);
    }

    @Test
    public void testMessageLength_Failure() {
        StringBuilder longContent = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            longContent.append("a");
        }
        Message message = new Message("MSG002", "0123456789", longContent.toString());
        String result = message.checkMessageLength();
        assertEquals("Message exceeds 250 characters by 10, please reduce size.", result);
    }

    @Test
    public void testRecipientCell_Success() {
        Message message = new Message("MSG003", "0823456789", "Test message.");
        String result = message.validateRecipientCell();
        assertEquals("Cell phone number successfully captured.", result);
    }

    @Test
    public void testRecipientCell_Failure() {
        Message message = new Message("MSG004", "823456789", "Test message.");
        String result = message.checkRecipientCell();
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
    }

    @Test
    public void testCreateMessageHash() {
        Message message = new Message("00", "0123456789", "Hi to night");
        String hash = message.createMessageHash();
        assertEquals("00:0:HITONIGHT", hash);
    }

    @Test
    public void testSentMessage_Send() {
        Message message = new Message("MSG005", "0123456789", "Hello");
        String result = message.sentMessage(1);
        assertEquals("Message successfully sent.", result);
    }

    @Test
    public void testSentMessage_Disregard() {
        Message message = new Message("MSG006", "0123456789", "Hello");
        String result = message.sentMessage(0);
        assertEquals("Press 0 to delete message.", result);
    }

    @Test
    public void testSentMessage_Store() {
        Message message = new Message("MSG007", "0123456789", "Hello");
        String result = message.sentMessage(2);
        assertEquals("Message successfully stored.", result);
    }
}
