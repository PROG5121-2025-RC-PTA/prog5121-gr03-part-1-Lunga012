
package com.mycompany.prog5121.poe.st10483560;

import javax.swing.JOptionPane;

public class Message {

public static boolean checkMessageID(String messageId) {
    if (messageId == null) {
        return false; 
    }
    return messageId.length() <= 10;
}
public static int checkRecipientCell(String cellNumber) {
    if (cellNumber == null || cellNumber.isEmpty()) {
        return 0;
    }
    // Alternatively, check for international format like '+27821234567'
    if (cellNumber.startsWith("+27") && cellNumber.length() == 12 && cellNumber.matches("\\+27\\d{9}")) {
        return 1;
    }
    return 0; 
}

   // public String createMessageHash() {
        // Implementation goes here
    //}

    Message(String string, String string0, String test_message) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    // Allows user to choose to send, store, or disregard a message
    public String sendMessage() {
        String sendMessage;
        sendMessage = JOptionPane.showInputDialog(null, "Please enter a message");
        if (sendMessage.equals("Send")){
            return "Message sent: " + sendMessage;
        } else if (sendMessage.equals("Store message")){
            return "Message stored: " + sendMessage;
        } else if (sendMessage.equals("Disregard Message")){
            return "Message disregared.";
        } else {
            return "No Option selected";
        }
    }

    // Returns a list of all the messages sent while the program is running
    public String printMessages(String message) {
        // Assuming 'messages' is a field of type List<String>.
    if (message.isEmpty()) {
        return "Message is empty\n Please try again";
    }
    return String.join("\n", message);
    }


    
    private int messageCount = 0;
    
    // Method to register a new message being sent
    public void registerMessage(String message) {
        messageCount++;
    }
    
    // Returns the total number of messages sent
    public int returnTotalMessages() {
        return messageCount;
    }
    // Processes user selection and returns the corresponding message.
    public String processUserSelection(int selection) {
        switch (selection) {
            case 1:
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid selection.";
        }
    }

    boolean checkMessageID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    boolean checkMessageID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object checkMessageLength() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    short checkRecipientCell() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

