package com.mycompany.prog5121.poe.st10483560;

import java.util.ArrayList;
import java.util.List;

public class Message {
    //Private strings
    private String messageID;
    private String recipientCell;
    private String messageContent;

    
    private static List<Message> messagesSent = new ArrayList<>();
    private static int totalMessages = 0;

    // Constructors for the cellphone number, message id and the the vontent of the message.
    public Message(String messageID, String recipientCell, String messageContent) {
        this.messageID = messageID;
        this.recipientCell = recipientCell;
        this.messageContent = messageContent;
    }

    // checks the meesage id if it is 10 charecters or not
    public boolean checkMessageID() {
        return (messageID != null && messageID.length() <= 10);
    }

// checks tha the cell phone number is 10charecters
    public int checkRecipientCell() {
        if (recipientCell != null && recipientCell.length() == 10 && recipientCell.startsWith("0")) {
            return 1;
        }
        return 0;
    }

// validates the cellphone number
    public String validateRecipientCell() {
        if (checkRecipientCell() == 1) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

// checjs the message legtht
    public String checkMessageLength() {
        int maxChars = 250;
        if (messageContent.length() <= maxChars) {
            return "Message ready to send.";
        } else {
            int excess = messageContent.length() - maxChars;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
    }

// creates the message harsh with th eocnditions
    public String createMessageHash() {
        // Split the message content to extract the first and last words
        String[] words = messageContent.trim().split("\\s+");
        String first = (words.length > 0) ? words[0].toUpperCase() : "";
        String last = (words.length > 0) ? words[words.length - 1].toUpperCase() : "";
        return messageID + ":" + totalMessages + ":" + first + last;
    }

// allows the useer to send or store messages
    public String sentMessage(int userChoice) {
        String response;
        switch (userChoice) {
            case 1: // send message
                response = "Message successfully sent.";
                messagesSent.add(this);
                totalMessages++;
                break;
            case 0: // disregard message
                response = "Press 0 to delete message.";
                break;
            case 2: // store message
                // Call storeMessage and assume that method saves the message as JSON
                storeMessage();
                response = "Message successfully stored.";
                break;
            default:
                response = "Invalid choice.";
                break;
        }
        return response;
    }

// prints sent messages to the user
    public String printMessages() {
        if (messagesSent.isEmpty()) {
            return "No messages sent.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : messagesSent) {
            sb.append("Message ID: ").append(m.messageID)
              .append(", Recipient: ").append(m.recipientCell)
              .append(", Content: ").append(m.messageContent).append("\n");
        }
        return sb.toString();
    }

    /**
     * Method: returnTotalMessagess
     * Functionality: Returns the total number of messages sent.
     * @return total message count.
     */
    public int returnTotalMessagess() {
        return totalMessages;
    }

// stores the message using JSON 
    public String storeMessage() {
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"messageID\":\"").append(messageID).append("\", ");
        json.append("\"recipientCell\":\"").append(recipientCell).append("\", ");
        json.append("\"messageContent\":\"").append(messageContent).append("\"");
        json.append("}");
        // Here you might normally write the JSON to disk or a database.
        return json.toString();
    }
}