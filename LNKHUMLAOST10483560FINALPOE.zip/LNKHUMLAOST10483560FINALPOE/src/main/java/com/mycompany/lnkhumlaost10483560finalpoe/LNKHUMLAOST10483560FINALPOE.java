

package com.mycompany.lnkhumlaost10483560finalpoe;

import javax.swing.*;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Message {
    String user;
    String messageID;
    int messageNum;
    String recipient;
    String message;
    String messageHash;

    public Message(String user, String messageID, int messageNum, String recipient, String message, String messageHash) {
        this.user = user;
        this.messageID = messageID;
        this.messageNum = messageNum;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = messageHash;
    }
    
    @Override
    public String toString() {
        return 
               "MessageID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message;
    }

    int message() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

public class LNKHUMLAOST10483560FINALPOE {
    
    // Store the logged-in username.
    static String loggedInUser = "";
    
    // Global arrays to hold messages and related details.
    static ArrayList<Message> sentMessages = new ArrayList<>();
    static ArrayList<Message> disregardedMessages = new ArrayList<>();
    static ArrayList<Message> storedMessages = new ArrayList<>();
    static ArrayList<String> messageHashArray = new ArrayList<>();
    static ArrayList<String> messageIDArray = new ArrayList<>();
    
    public static void main(String[] args) {
       // Welcome messages
        UIManager.put("OptionPane.okButtonText", "Continue");
        JOptionPane.showMessageDialog(
                null, "Welcome to ChatApp");
        
        UIManager.put("OptionPane.okButtonText", "OK");
        JOptionPane.showMessageDialog(
                null, "Click here to Register and Login-in.");
        
        UIManager.put("OptionPane.okButtonText", "Continue");
        JOptionPane.showMessageDialog(
                null, "Create an account by entering a username, password, and South African cellphone number.");
        
        // Get first and last name
        String firstname;
        firstname = JOptionPane.showInputDialog(
                null, "Please enter your first name");
        String lastname;
        lastname = JOptionPane.showInputDialog(
                null, "Please enter your last name");
        
        // The username must contain an underscore and be no more than five characters in length.
        String username;
        username = JOptionPane.showInputDialog(
                null, "Please enter your username");
        if (username != null 
                && username.contains("_") 
                && username.length() <= 5) {
            JOptionPane.showMessageDialog(
                    null, "Username successfully captured");
        } else {
            JOptionPane.showMessageDialog(
                    null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
        }
        
        // Prompt the user to enter the password 
        String password = JOptionPane.showInputDialog(
                null, "Please enter a password");
        if (password != null &&
            password.length() >= 8 &&
            password.matches(".*[A-Z].*") &&
            password.matches(".*[0-9].*") &&
            password.matches(".*[!@#$%].*")) {
            
            JOptionPane.showMessageDialog(
                        null, "Password successfully captured");
        } else {
            JOptionPane.showMessageDialog(
                        null, "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
        }
        
        // Get cellphone number and validate with regex:
        String phoneNumber = JOptionPane.showInputDialog(
                null, "Please enter your cellphone number.");
        String regex = "^\\+\\d{1,3}\\d{1,10}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(phoneNumber);
        
        
        if (phoneNumber != null && matcher.matches() && phoneNumber.length() == 12) {
            JOptionPane.showMessageDialog(
                        null, "Cellphone number successfully added");
        } else {
            JOptionPane.showMessageDialog(
                        null, "Cellphone number incorrectly formatted or does not contain international code");
        }
        
        // Verifying if the details are correct or not
        if (username != null && username.contains("_") && username.length() <= 5 &&
            password != null && password.length() >= 8 &&
            password.matches(".*[A-Z].*") &&
            password.matches(".*[0-9].*") &&
            password.matches(".*[!@#$%].*") &&
            phoneNumber != null && phoneNumber.matches("^\\+\\d{1,3}[ -]?\\d{10}$")) {
            JOptionPane.showMessageDialog(null, "Welcome " + firstname + " " + lastname + " it is great to see you again.");
        }

        
        // --- WELCOME MESSAGE ---
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        
        // --- LOAD STORED MESSAGES ---
        // The JSON stored messages are read into the storedMessages array.
        storedMessages = loadStoredMessagesFromJSON();
        
        // --- NUMBER OF MESSAGES ---
        int totalMessages = 0;
        boolean validNumber = false;
        while (!validNumber) {
            try {
                totalMessages = Integer.parseInt(JOptionPane.showInputDialog(
                        "How many messages you want to send? "));
                if (totalMessages > 0) {
                    validNumber = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a number greater than 0.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
            }
        }
        
        int messagesProcessed = 0;
        
        //MAIN MENU
        while (true) {
            String mainMenu = "Choose an option from the numeric menu:\n"
                            + "1) Send Messages\n"
                            + "2) Show recently sent messages\n"
                            + "3) Array Operations\n"
                            + "4) Quit";
            String option = JOptionPane.showInputDialog(mainMenu);
            if (option == null) continue;
            
            switch(option) {
                case "1":
                    if (messagesProcessed >= totalMessages) {
                        JOptionPane.showMessageDialog(null, "You have reached the maximum number of messages.\n "
                                + "Please try agin!");
                        break;
                    }
                    
                    
                    // Validate recipient: must not exceed 10 characters and include an international dialing code.
                    String recipient = null;
                    boolean validRecipient = false;
                    while (!validRecipient) {
                recipient = JOptionPane.showInputDialog(null,"Please enter the receipients phone number");
                if (recipient == null)
                    break;
                if (recipient.matches("^\\+\\d{1,3}[ -]?\\d{10}$")){
                    validRecipient = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Cellphone number is incorrectly formattted or does not contain an international code. Please correct that and try again");
                }
                    }
                    if (recipient == null) break;
                    
                    //If the message exceeds 50 characters, display an error message.
                    String messageText = "";
                    boolean validMessage = false;
                    while (!validMessage) {
                        messageText = JOptionPane.showInputDialog("Enter your message (less than 50 characters):");
                        if (messageText == null) break;
                        if (messageText.length() < 50) {
                            validMessage = true;
                        } else {
                            JOptionPane.showMessageDialog(null, "Please enter a message of less than 50 characters.");
                        }
                    }
                    if (messageText == null) break;
                    
                    // --- GENERATE MESSAGE IDENTIFIERS ---
                    String messageID = generateRandom10Digit();
                    messagesProcessed++;
                    String messageHash = generateMessageHash(messageID, messagesProcessed, messageText);
                    
                    // Add to arrays that hold IDs and Hashes.
                    messageIDArray.add(messageID);
                    messageHashArray.add(messageHash);
                    
                    // --- MESSAGE SUB-MENU ---
                    // The user is given three choices: send, disregard, or store the message.
                    Object[] optionsSub = {"Send Message", "Disregard Message", "Store Message to send later"};
                    int subChoice = JOptionPane.showOptionDialog(null,
                            "Choose an option for this message:",
                            "Message Options",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.INFORMATION_MESSAGE,
                            null,
                            optionsSub,
                            optionsSub[0]);
                    
                    if (subChoice == 0) {
                        // If sent, store the message in the sentMessages array.
                        JOptionPane.showMessageDialog(
                                null, "Message sent.");
                        Message msg = new Message(
                                loggedInUser, messageID, messagesProcessed, recipient, messageText, messageHash);
                        sentMessages.add(msg);
                        JOptionPane.showMessageDialog(null, msg.toString());
                    } else if (subChoice == 1) {
                        // If disregarded, store the message in the disregardedMessages array.
                        JOptionPane.showMessageDialog(
                                null, "Message disregarded.");
                        Message msg = new Message(
                                loggedInUser, messageID, messagesProcessed, recipient, messageText, messageHash);
                        disregardedMessages.add(msg);
                    } else if (subChoice == 2) {
                        // If stored, add the message to the storedMessages array and write it to the JSON file.
                        JOptionPane.showMessageDialog(
                                null, "Message stored to send later.");
                        Message msg = new Message(
                                loggedInUser, messageID, messagesProcessed, recipient, messageText, messageHash);
                        storedMessages.add(msg);
                        storeMessageToJSON(msg);
                        JOptionPane.showMessageDialog(
                                null, msg.toString());
                    }
                    break;

                
                case "2":
                    JOptionPane.showMessageDialog(
                            null, "Coming Soon.");
                    break;
                
                case "3":
                    //ARRAY OPERATIONS MENU
                    handleArrayOperations();
                    break;
                
                case "4":
                    JOptionPane.showMessageDialog(
                            null, "Total messages processed: " + messagesProcessed);
                // A goodbye message must dispaly and breaks thee loop.
                    JOptionPane.showMessageDialog(
                        null, "Thank you for using QuickChat. Goodbye!");
                    System.exit(0);
                    break;
                
                default:
                    JOptionPane.showMessageDialog(
                            null, "Invalid option. Please try again.");
                    break;
            }
        }
    }
    
    // Generates a random 10-digit number (as a String).
    private static String generateRandom10Digit() {
        Random rnd = new Random();
        long number = (long) (1000000000L + rnd.nextDouble() * 9000000000L);
        return Long.toString(number);
    }
    
    // Generates a message hash in the form
    private static String generateMessageHash(String messageID, int messageNum, String messageText) {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord;
            firstWord = words.length > 0 ? words[0] : "";
        String lastWord;
            lastWord= words.length > 0 ? words[words.length - 1] : "";
        String hash;
            hash = firstTwo + ":" + messageNum + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }
    
    // Stores the message details into a JSON file. Here a single line JSON format is used so that it can be parsed later.
    private static void storeMessageToJSON(Message msg) {
        try (FileWriter file = new FileWriter("messages.json", true)) {
            String json = "{\"Sender\":\"" + msg.user + "\","
                        + "\"MessageID\":\"" + msg.messageID + "\","
                        + "\"MessageHash\":\"" + msg.messageHash + "\","
                        + "\"Recipient\":\"" + msg.recipient + "\","
                        + "\"Message\":\"" + msg.message + "\"}\n";
            file.write(json);
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error storing message to JSON: " + e.getMessage());
        }
    }
    
    // Reads the JSON file ("messages.json") and returns an ArrayList of stored Message objects.
    private static ArrayList<Message> loadStoredMessagesFromJSON() {
        ArrayList<Message> storedMsgs = new ArrayList<>();
        File f = new File("messages.json");
        if (!f.exists()) {
            return storedMsgs;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                // Simple JSON parsing assuming the JSON structure never changes.
                if (line.startsWith("{") && line.endsWith("}")) {
                    line = line.substring(1, line.length() - 1); // remove curly braces
                    String[] parts = line.split("\",");
                    String user = "";
                    String messageID = "";
                    String messageHash = "";
                    String recipient = "";
                    String messageText = "";
                    for (String part : parts) {
                        part = part.replace("\"", "").trim();
                        String[] keyVal = part.split(":", 2);
                        if (keyVal.length < 2) continue;
                        String key = keyVal[0].trim();
                        String value = keyVal[1].trim();
                        switch(key) {
                            case "User": user = value; break;
                            case "MessageID": messageID = value; break;
                            case "MessageHash": messageHash = value; break;
                            case "Recipient": recipient = value; break;
                            case "Message": messageText = value; break;
                        }
                    }
                    // For messages loaded from storage.
                    Message msg = new Message(user, messageID, 0, recipient, messageText, messageHash);
                    storedMsgs.add(msg);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading stored messages: " + e.getMessage());
        }
        return storedMsgs;
    }
    
    // Displays the Array Operations sub-menu and processes user selections.
    private static void handleArrayOperations() {
        boolean back = false;
        while (!back) {
            String arrayMenu = "Array Operations:\n"
                             + "a) Display the sender and recipient of all sent messages.\n"
                             + "b) Display the longest sent message.\n"
                             + "c) Search by Message ID and display the corresponding recipient and message.\n"
                             + "d) Search for all messages sent to a particular recipient.\n"
                             + "e) Delete a message using the message hash.\n"
                             + "f) Display a report with full details of all sent messages.\n"
                             + "g) Go Back.\n"
                             + "Enter your choice (a-g):";
            String choice = JOptionPane.showInputDialog(arrayMenu);
            if (choice == null) continue;
            choice = choice.toLowerCase();
            switch(choice) {
                case "a":
                    displaySenderAndRecipient();
                    break;
                case "b":
                    displayLongestSentMessage();
                    break;
                case "c":
                    searchByMessageID();
                    break;
                case "d":
                    searchByRecipient();
                    break;
                case "e":
                    deleteMessageByHash();
                    break;
                case "f":
                    displaySentMessagesReport();
                    break;
                case "g":
                    back = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please choose between a and g.");
                    break;
            }
        }
    }
    
    // Option (a): Display the sender and recipient of all sent messages.
    private static void displaySenderAndRecipient() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages available.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Sender: ").append(m.user)
              .append(", Recipient: ").append(m.recipient)
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
    
    // Option (b): Display the longest sent message.
    private static void displayLongestSentMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages available.");
            return;
        }
        Message longest = null;
        for (Message m : sentMessages) {
            if (longest == null || m.message.length() > longest.message()) {
                longest = m;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest message: " + longest.message);
    }
    
    // Option (c): Search for a message ID and display its recipient and message.
    private static void searchByMessageID() {
        String searchID = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (searchID == null || searchID.trim().isEmpty()) return;
        boolean found = false;
        for (Message m : sentMessages) {
            if (m.messageID.equals(searchID)) {
                JOptionPane.showMessageDialog(null, "Recipient: " + m.recipient + "\nMessage: " + m.message);
                found = true;
                break;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "Message with ID " + searchID + " not found.");
        }
    }
    
    // Option (d): Search for all messages sent to a particular recipient.
    private static void searchByRecipient() {
        String searchRecipient = JOptionPane.showInputDialog("Enter recipient to search for:");
        if (searchRecipient == null || searchRecipient.trim().isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            if (m.recipient.equals(searchRecipient)) {
                sb.append("MessageID: ").append(m.messageID)
                  .append(", Message: ").append(m.message).append("\n");
            }
        }
        if (sb.length() == 0) {
            JOptionPane.showMessageDialog(null, "No messages found for recipient " + searchRecipient);
        } else {
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }
    
    // Option (e): Delete a message using the message hash.
    private static void deleteMessageByHash() {
        String searchHash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
        if (searchHash == null || searchHash.trim().isEmpty()) return;
        boolean removed = false;
        for (int i = 0; i < sentMessages.size(); i++) {
            Message m = sentMessages.get(i);
            if (m.messageHash.equalsIgnoreCase(searchHash)) {
                sentMessages.remove(i);
                // Also remove from the message ID and message hash arrays.
                messageIDArray.remove(m.messageID);
                messageHashArray.remove(m.messageHash);
                removed = true;
                JOptionPane.showMessageDialog(null, "Message deleted successfully.");
                break;
            }
        }
        if (!removed) {
            JOptionPane.showMessageDialog(null, "No message found with hash " + searchHash);
        }
    }
    
    // Option (f): Display a report listing full details of all sent messages.
    private static void displaySentMessagesReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append(m.toString()).append("\n----------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
